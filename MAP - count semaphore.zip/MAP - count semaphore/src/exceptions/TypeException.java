package exceptions;

public class TypeException extends InterpreterException {
    public TypeException(String message) {
        super(message);
    }
}