package exceptions;

public class FileException extends InterpreterException{
    public FileException(String message) {
        super(message);
    }
}