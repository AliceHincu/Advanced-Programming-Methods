package exceptions;

public class ExpressionException extends InterpreterException{
    public ExpressionException(String message) {
        super(message);
    }
}
