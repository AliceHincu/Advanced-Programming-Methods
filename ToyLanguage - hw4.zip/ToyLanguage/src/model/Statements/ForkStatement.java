package model.Statements;

import exceptions.AdtException;
import exceptions.InterpreterException;
import model.ADTs.MyDictionary;
import model.ADTs.MyDictionaryInterface;
import model.ADTs.MyStack;
import model.ADTs.MyStackInterface;
import model.ProgramState;
import model.Values.StringValue;
import model.Values.Value;

import java.io.BufferedReader;
import java.util.Map;
import java.util.stream.Collectors;

public class ForkStatement implements StatementInterface{
    private final StatementInterface forkStatement;

    public ForkStatement(StatementInterface forkStatement){
        this.forkStatement = forkStatement;
    }

    @Override
    public ProgramState execute(ProgramState state) throws InterpreterException {
        MyStackInterface<StatementInterface> newExeStack = new MyStack<>();
        newExeStack.push(forkStatement);
        MyDictionaryInterface<String, Value> newSymTable;
        newSymTable = this.deepCopySymbolTabel(state.getSymbolTable());

        ProgramState newProgramState = new ProgramState(newExeStack, newSymTable, state.getOut(), state.getFileTable(), state.getHeap());
        newProgramState.setId();
        return newProgramState;
    }

    @Override
    public StatementInterface deepCopy() {
        return new ForkStatement(this.forkStatement);
    }

    private MyDictionaryInterface<String, Value> deepCopySymbolTabel(MyDictionaryInterface<String, Value> oldSymbolTable) throws AdtException {
        MyDictionaryInterface<String, Value> newSymTable = new MyDictionary<>();

        for(Map.Entry<String, Value> element: oldSymbolTable.getContent().entrySet()){
            String newKey = element.getKey();
            Value newValue = element.getValue().deepCopy();
            newSymTable.add(newKey, newValue);
        }
        return newSymTable;
    }

    @Override
    public String toString() {
        return "fork(" + this.forkStatement.toString() + ")";
    }

}
