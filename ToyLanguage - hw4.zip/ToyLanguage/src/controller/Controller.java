package controller;


import exceptions.InterpreterException;
import model.ProgramState;
import model.Values.RefValue;
import model.Values.Value;
import repository.RepositoryInterface;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Controller {
    private RepositoryInterface repo;
    private boolean displayFlag;
    private ExecutorService executor;

    public Controller(RepositoryInterface repo) {
        this.repo = repo;
        this.displayFlag = false;
    }

    public void addProgram(ProgramState newProgram) {
        this.repo.addProgram(newProgram);
    }

    public List<ProgramState> removeCompletedPrograms(List<ProgramState> inputProgramList) {
        return inputProgramList.stream().filter(ProgramState::isNotCompleted).collect(Collectors.toList());
    }


    public void allSteps() throws InterpreterException {
        this.executor = Executors.newFixedThreadPool(2);
        // remove the completed programs
        List<ProgramState> prgList = removeCompletedPrograms(repo.getProgramList());
        while(prgList.size() > 0){
            conservativeGarbageCollector(prgList);
            oneStepForAllPrg(prgList);
            // remove the completed programs
            prgList = removeCompletedPrograms(repo.getProgramList());
        }
        executor.shutdownNow();
        // HERE the repository still contains at least one Completed Prg
        // and its List<PrgState> is not empty. Note that oneStepForAllPrg calls the method
        // setPrgList of repository in order to change the repository

        // update the repository state
        repo.setProgramList(prgList);
    }

    public void oneStepForAllPrg(List<ProgramState> programList) throws InterpreterException {
        programList.forEach(state -> {
            //PRINT the PrgState List into the log file
            //-----------------------------------------------------------------------
            try {
                this.repo.logProgramStateExecution(state);
            } catch (InterpreterException exception) {
                // prints the throwable along with other details like the line number and class name where the exception occurred
                exception.printStackTrace();
            }
        });

        //RUN concurrently one step for each of the existing PrgStates
        //-----------------------------------------------------------------------
        // prepare the list of callables -> task that is intended to be executed concurrently by a separate thread
        List<Callable<ProgramState>> callList = programList.stream()
                .map((ProgramState p)->(Callable<ProgramState>)(p::oneStep))
                .collect(Collectors.toList());

        // start the execution of the callables
        // it returns the list of new created PrgStates(namely, threads)
        try {
            List<ProgramState> newProgramList = executor.invokeAll(callList).stream()
                    .map(future -> {
                        try {
                            return future.get();
                        } catch (InterruptedException | ExecutionException e) {
                            System.out.println(e.getMessage());
                        }
                        return null;
                    })
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
            programList.addAll(newProgramList);
        } catch (InterruptedException e) {
            throw new InterpreterException(e.getMessage());
        }

        // after the execution, print the PrgState List into the log file
        programList.forEach(prg -> {
            try {
                this.repo.logProgramStateExecution(prg);
            } catch (InterpreterException exception) {
                exception.printStackTrace();
            }
        });

        // Save the current programs in the repository
        this.repo.setProgramList(programList);
    }




    private void conservativeGarbageCollector(List<ProgramState> programStateList) {
        // get the heap of each program state and concatenate it
        var heap = Objects.requireNonNull(
                programStateList.stream()
                        .map(p -> getAddressesFromSymbolTable(
                                p.getSymbolTable().getContent().values(),
                                p.getHeap().getHeap().values()))
                        .map(Collection::stream)
                        .reduce(Stream::concat).orElse(null)).collect(Collectors.toList());

        // call safeGarbageCollector for each heap
        programStateList.forEach(programState -> programState.getHeap().setHeap(safeGarbageCollector(
                heap,
                programStateList.get(0).getHeap().getHeap()

        )));

    }

    private Map<Integer, Value> safeGarbageCollector(List<Integer> symbolTableAddresses, Map<Integer, Value> heap) {
        /* transformi dict in set, vezi daca ce e in symbol table se afla si in heap, salvezi intr-un map*/
        return heap.entrySet().stream()
                .filter(e -> symbolTableAddresses.contains(e.getKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }


    //safe
    private List<Integer> getAddressesFromSymbolTable(Collection<Value> symbolTableValue, Collection<Value> heap) {
        return Stream.concat(
                heap.stream()
                        .filter(v -> v instanceof RefValue)
                        .map(v -> {
                            RefValue v1 = (RefValue) v;
                            return v1.getAddress();
                        }),
                symbolTableValue.stream()
                        .filter(v -> v instanceof RefValue)
                        .map(v -> {
                            RefValue v1 = (RefValue) v;
                            return v1.getAddress();
                        })
        ).collect(Collectors.toList());
    }


    public String displayState(ProgramState state) {
        return state.toString();
    }

    public void setDisplayAll(Boolean flag) {
        this.displayFlag = flag;
    }


    /*
    public void allSteps() throws InterpreterException{
        ProgramState prg = repo.getCurrentProgram(); // repo is the controller field of type MyRepoInterface
        if(this.displayFlag)
            System.out.println(displayState(prg));
        repo.logProgramStateExecution(prg);
        while(!prg.getExeStack().isEmpty()){
            try{
                oneStep(prg);
            }catch(Exception e){
                throw new InterpreterException(e.getMessage());
            }
            if(this.displayFlag)
                System.out.println(displayState(prg));
            repo.logProgramStateExecution(prg);

            // unsafe garbage
            /*MyHeapInterface<Value> auxHeap = new MyHeap<>();
            auxHeap.setHeap(unsafeGarbageCollector(
                    getAddressesFromSymbolTable(prg.getSymbolTable().values()),
                    prg.getHeap().getHeap())
            );
            prg.getHeap().setHeap(auxHeap.getHeap());*/

    // safe
    // Ca sa fie safe, am salvat atat refValues din symbol table, cat si cele din heap. Iau adresele de la cele
    // n refValues. Astfel salvez toate referintele.
    // De ce era unsafe inainte? Pt ca eu daca alocam new(v,20) si dupa new(v, 30), in symbol table din
    // {a=(2, Ref(int)), v=(1, int)} se facea {a=(2, Ref(int)), v=(3, int)}, dar in heap aveam {1=20, 2=(1, int), 3=30}
    // daca luam doar refValues din symbtable, ramaneam cu adresele 2 si 3. Daca iau si din heap refValues, o
    // sa am si adresa 1.
    /*
            MyHeapInterface<Value> auxHeap = new MyHeap<>();
            auxHeap.setHeap(unsafeGarbageCollector(
                    getAddressesFromSymbolTable(prg.getSymbolTable().values(), prg.getHeap().getHeap().values()),
                    prg.getHeap().getHeap())
            );
            prg.getHeap().setHeap(auxHeap.getHeap());
        }
    }*/

}