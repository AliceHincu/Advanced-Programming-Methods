package exceptions;

public class StatementException extends InterpreterException{
    public StatementException(String message) {
        super(message);
    }
}
