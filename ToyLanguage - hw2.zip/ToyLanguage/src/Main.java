import controller.Controller;
import exceptions.FileException;
import model.ADTs.MyDictionary;
import model.ADTs.MyList;
import model.ADTs.MyStack;
import model.ProgramState;
import model.Statements.StatementInterface;
import repository.Repository;
import repository.RepositoryInterface;
import view.Commands.ExitCommand;
import view.Commands.RunExample;
import view.Examples;
import view.TextMenu;

public class Main {
    public static void main(String[] args) {
        StatementInterface[] examples = new Examples().exampleList();
        StatementInterface example1, example2, example3, example4;
        ProgramState prg1, prg2, prg3, prg4;
        RepositoryInterface repo1, repo2, repo3, repo4;
        Controller controller1, controller2, controller3, controller4;

        try{
            example1 = examples[0];
            prg1 = new ProgramState(new MyStack<>(), new MyDictionary<>(), new MyList<>(),
                                    new MyDictionary<>(), example1);
            repo1 = new Repository("log1.txt");
            repo1.addProgram(prg1);
            controller1 = new Controller(repo1);

            example2 = examples[1];
            prg2 = new ProgramState(new MyStack<>(), new MyDictionary<>(), new MyList<>(),
                                    new MyDictionary<>(), example2);
            repo2 = new Repository("log2.txt");
            repo2.addProgram(prg2);
            controller2 = new Controller(repo2);

            example3 = examples[2];
            prg3 = new ProgramState(new MyStack<>(), new MyDictionary<>(), new MyList<>(),
                                    new MyDictionary<>(), example3);
            repo3 = new Repository("log3.txt");
            repo3.addProgram(prg3);
            controller3 = new Controller(repo3);

            example4 = examples[3];
            prg4 = new ProgramState(new MyStack<>(), new MyDictionary<>(), new MyList<>(),
                                    new MyDictionary<>(), example4);
            repo4 = new Repository("log4.txt");
            repo4.addProgram(prg4);
            controller4 = new Controller(repo4);


            TextMenu menu = new TextMenu();
            menu.addCommand(new ExitCommand("0", "exit"));
            menu.addCommand(new RunExample("1", example1.toString(), controller1));
            menu.addCommand(new RunExample("2", example2.toString(), controller2));
            menu.addCommand(new RunExample("3", example3.toString(), controller3));
            menu.addCommand(new RunExample("4", example4.toString(), controller4));

            menu.show();
        } catch(FileException exception) {
            System.out.println("File cannot be close " + exception.getMessage());
        }
    }
}
