package exceptions;

public class AdtException extends InterpreterException {
    public AdtException(String msg){
        super(msg);
    }
}